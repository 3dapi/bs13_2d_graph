// ClrModelDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ClrModel.h"
#include "ClrModelDlg.h"

#include "ColorModel.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CClrModelDlg dialog

CClrModelDlg::CClrModelDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CClrModelDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CClrModelDlg)
	m_cmy_c = 0.0;
	m_cmy_m = 0.0;
	m_cmy_y = 0.0;
	m_gray = 0.0;
	m_hls_h = 0.0;
	m_rgb_r = 0.0;
	m_rgb_g = 0.0;
	m_rgb_b = 0.0;
	m_hls_l = 0.0;
	m_hls_s = 0.0;
	m_hsv_h = 0.0;
	m_hsv_s = 0.0;
	m_hsv_v = 0.0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CClrModelDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CClrModelDlg)
	DDX_Text(pDX, IDC_CMY_C, m_cmy_c);
	DDX_Text(pDX, IDC_CMY_M, m_cmy_m);
	DDX_Text(pDX, IDC_CMY_Y, m_cmy_y);
	DDX_Text(pDX, IDC_GRAY, m_gray);
	DDX_Text(pDX, IDC_HLS_H, m_hls_h);
	DDX_Text(pDX, IDC_RGB_R, m_rgb_r);
	DDX_Text(pDX, IDC_RGB_G, m_rgb_g);
	DDX_Text(pDX, IDC_RGB_B, m_rgb_b);
	DDX_Text(pDX, IDC_HLS_L, m_hls_l);
	DDX_Text(pDX, IDC_HLS_S, m_hls_s);
	DDX_Text(pDX, IDC_HSV_H, m_hsv_h);
	DDX_Text(pDX, IDC_HSV_S, m_hsv_s);
	DDX_Text(pDX, IDC_HSV_V, m_hsv_v);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CClrModelDlg, CDialog)
	//{{AFX_MSG_MAP(CClrModelDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_RGB, OnRgb)
	ON_BN_CLICKED(IDC_HSV, OnHsv)
	ON_BN_CLICKED(IDC_HLS, OnHls)
	ON_BN_CLICKED(IDC_CMY, OnCmy)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CClrModelDlg message handlers

BOOL CClrModelDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CClrModelDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CClrModelDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CClrModelDlg::OnRgb() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	
	RGB_To_HSV(m_rgb_r, m_rgb_g, m_rgb_b, m_hsv_h, m_hsv_s, m_hsv_v);
	RGB_To_HLS(m_rgb_r, m_rgb_g, m_rgb_b, m_hls_h, m_hls_l, m_hls_s);
	RGB_To_CMY(m_rgb_r, m_rgb_g, m_rgb_b, m_cmy_c, m_cmy_m, m_cmy_y);
	RGB_To_Gray(m_rgb_r, m_rgb_g, m_rgb_b, m_gray);

	UpdateData(FALSE);
}

void CClrModelDlg::OnHsv() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);

	HSV_To_RGB(m_hsv_h, m_hsv_s, m_hsv_v, m_rgb_r, m_rgb_g, m_rgb_b);
	RGB_To_HLS(m_rgb_r, m_rgb_g, m_rgb_b, m_hls_h, m_hls_l, m_hls_s);
	RGB_To_CMY(m_rgb_r, m_rgb_g, m_rgb_b, m_cmy_c, m_cmy_m, m_cmy_y);
	RGB_To_Gray(m_rgb_r, m_rgb_g, m_rgb_b, m_gray);

	UpdateData(FALSE);
}

void CClrModelDlg::OnHls() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);

	HLS_To_RGB(m_hls_h, m_hls_l, m_hls_s, m_rgb_r, m_rgb_g, m_rgb_b);
	RGB_To_HSV(m_rgb_r, m_rgb_g, m_rgb_b, m_hsv_h, m_hsv_s, m_hsv_v);
	RGB_To_CMY(m_rgb_r, m_rgb_g, m_rgb_b, m_cmy_c, m_cmy_m, m_cmy_y);
	RGB_To_Gray(m_rgb_r, m_rgb_g, m_rgb_b, m_gray);

	UpdateData(FALSE);
}

void CClrModelDlg::OnCmy() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);

	CMY_To_RGB(m_cmy_c, m_cmy_m, m_cmy_y, m_rgb_r, m_rgb_g, m_rgb_b);
	RGB_To_HSV(m_rgb_r, m_rgb_g, m_rgb_b, m_hsv_h, m_hsv_s, m_hsv_v);
	RGB_To_HLS(m_rgb_r, m_rgb_g, m_rgb_b, m_hls_h, m_hls_l, m_hls_s);
	RGB_To_Gray(m_rgb_r, m_rgb_g, m_rgb_b, m_gray);

	UpdateData(FALSE);	
}