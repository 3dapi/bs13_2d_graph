// ClrModelDlg.h : header file
//

#if !defined(AFX_CLRMODELDLG_H__4D8AE355_F1EC_11D3_B8C2_F6D0BFF524B3__INCLUDED_)
#define AFX_CLRMODELDLG_H__4D8AE355_F1EC_11D3_B8C2_F6D0BFF524B3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CClrModelDlg dialog

class CClrModelDlg : public CDialog
{
// Construction
public:
	CClrModelDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CClrModelDlg)
	enum { IDD = IDD_CLRMODEL_DIALOG };
	FLOAT	m_cmy_c;
	FLOAT	m_cmy_m;
	FLOAT	m_cmy_y;
	FLOAT	m_gray;
	FLOAT	m_hls_h;
	FLOAT	m_rgb_r;
	FLOAT	m_rgb_g;
	FLOAT	m_rgb_b;
	FLOAT	m_hls_l;
	FLOAT	m_hls_s;
	FLOAT	m_hsv_h;
	FLOAT	m_hsv_s;
	FLOAT	m_hsv_v;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CClrModelDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CClrModelDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnRgb();
	afx_msg void OnHsv();
	afx_msg void OnHls();
	afx_msg void OnCmy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CLRMODELDLG_H__4D8AE355_F1EC_11D3_B8C2_F6D0BFF524B3__INCLUDED_)
