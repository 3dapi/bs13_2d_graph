//
////////////////////////////////////////////////////////////////////////////////


#ifndef _COLOR_CONVERT_H_
#define _COLOR_CONVERT_H_

void RGB_To_Gray(FLOAT r, FLOAT g, FLOAT b, FLOAT& gray);
void Gray_To_RGB(FLOAT gray, FLOAT& r, FLOAT& g, FLOAT& b);
void RGB_To_CMY(FLOAT r, FLOAT g, FLOAT b, FLOAT& c, FLOAT& m, FLOAT& y);
void CMY_To_RGB(FLOAT c, FLOAT m, FLOAT y, FLOAT& r, FLOAT& g, FLOAT& b);
void RGB_To_HSV(FLOAT r, FLOAT g, FLOAT b, FLOAT& h, FLOAT& s, FLOAT& v);
void HSV_To_RGB(FLOAT h, FLOAT s, FLOAT v, FLOAT& r, FLOAT& g, FLOAT& b);
void RGB_To_HLS(FLOAT r, FLOAT g, FLOAT b, FLOAT& h, FLOAT& l, FLOAT& s);
void HLS_To_RGB(FLOAT h, FLOAT l, FLOAT s, FLOAT& r, FLOAT& g, FLOAT& b);


#endif