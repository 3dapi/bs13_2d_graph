//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ClrModel.rc
//
#define IDD_CLRMODEL_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDC_RGB_R                       1000
#define IDC_RGB_G                       1001
#define IDC_RGB_B                       1002
#define IDC_HSV_H                       1003
#define IDC_HSV_S                       1004
#define IDC_HSV_V                       1005
#define IDC_HLS_H                       1006
#define IDC_HLS_L                       1007
#define IDC_HLS_S                       1008
#define IDC_CMY_C                       1009
#define IDC_CMY_M                       1010
#define IDC_CMY_Y                       1011
#define IDC_GRAY                        1012
#define IDC_RGB                         1013
#define IDC_HSV                         1014
#define IDC_HLS                         1015
#define IDC_CMY                         1016
#define IDC_CHECK                       1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
